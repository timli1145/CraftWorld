from PIL import Image, ImageDraw

# 创建一个非常明显的彩色方块图标
size = 256
img = Image.new('RGB', (size, size), (255, 165, 0))  # 橙色背景
draw = ImageDraw.Draw(img)

# 画一个大的绿色方块
draw.rectangle([20, 20, size-20, size-20], fill=(34, 139, 34), outline=(0, 0, 0), width=8)

# 画多个明显的黑点
# 1点
draw.ellipse([100, 100, 156, 156], fill=(0, 0, 0))
# 2点
draw.ellipse([60, 60, 96, 96], fill=(0, 0, 0))
draw.ellipse([160, 160, 196, 196], fill=(0, 0, 0))

# 保存为PNG
img.save('icon.png')

# 保存为ICO，包含多个尺寸
img.save('icon.ico', format='ICO', sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("Icon created successfully!")
