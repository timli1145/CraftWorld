from OpenGL.GL import *
from OpenGL.GLU import *
import math

class AnimatedPlayerModel:
    def __init__(self):
        self.animation_time = 0.0
        self.is_walking = False
        self.walk_speed = 8.0
        
        # 参照方块是 1.0 单位
        # 身体：底部边长一半的长方体 (0.5x0.5x0.5) - 底部边长一半，高度也是一半
        self.body_width = 0.5
        self.body_height = 0.5
        self.body_depth = 0.5
        
        # 四肢：四分之一个方块长条形竖着（身体一半高）
        # 四分之一个方块：宽度和深度0.25，竖着放高度是身体一半0.25
        self.limb_width = 0.25
        self.limb_depth = 0.25
        self.limb_height = self.body_height / 2
        
        # 头部：四肢一半的大小 - 每个维度都是四肢的一半
        self.head_width = self.limb_width / 2
        self.head_height = self.limb_height / 2
        self.head_depth = self.limb_depth / 2
        
        # 颜色
        self.skin_color = (0.9, 0.75, 0.6)  # 肤色
        self.shirt_color = (0.2, 0.5, 0.9)   # 蓝色衣服
        self.pants_color = (0.2, 0.2, 0.4)   # 深蓝色裤子
    
    def update(self, delta_time, is_moving):
        self.is_walking = is_moving
        if is_moving:
            self.animation_time += delta_time * self.walk_speed
    
    def draw_cube(self, w, h, d, color):
        glColor3f(*color)
        glBegin(GL_QUADS)
        
        # 前面
        glVertex3f(-w/2, 0, -d/2)
        glVertex3f(w/2, 0, -d/2)
        glVertex3f(w/2, h, -d/2)
        glVertex3f(-w/2, h, -d/2)
        
        # 后面
        glVertex3f(-w/2, 0, d/2)
        glVertex3f(-w/2, h, d/2)
        glVertex3f(w/2, h, d/2)
        glVertex3f(w/2, 0, d/2)
        
        # 左面
        glVertex3f(-w/2, 0, -d/2)
        glVertex3f(-w/2, h, -d/2)
        glVertex3f(-w/2, h, d/2)
        glVertex3f(-w/2, 0, d/2)
        
        # 右面
        glVertex3f(w/2, 0, -d/2)
        glVertex3f(w/2, 0, d/2)
        glVertex3f(w/2, h, d/2)
        glVertex3f(w/2, h, -d/2)
        
        # 顶面
        glVertex3f(-w/2, h, -d/2)
        glVertex3f(w/2, h, -d/2)
        glVertex3f(w/2, h, d/2)
        glVertex3f(-w/2, h, d/2)
        
        # 底面
        glVertex3f(-w/2, 0, -d/2)
        glVertex3f(-w/2, 0, d/2)
        glVertex3f(w/2, 0, d/2)
        glVertex3f(w/2, 0, -d/2)
        
        glEnd()
    
    def draw_limb(self, w, h, d, color, swing_angle=0, pivot_x=0, pivot_y=0, pivot_z=0):
        glPushMatrix()
        glTranslatef(pivot_x, pivot_y, pivot_z)
        glRotatef(swing_angle, 1, 0, 0)
        glTranslatef(-pivot_x, -pivot_y, -pivot_z)
        self.draw_cube(w, h, d, color)
        glPopMatrix()
    
    def draw(self):
        glPushMatrix()
        
        # 计算动画摆动角度
        swing_angle = 0.0
        if self.is_walking:
            swing_angle = math.sin(self.animation_time) * 40.0
        
        # 计算总高度，调整位置让模型站在地面上
        total_height = self.limb_height + self.body_height + self.head_height
        glTranslatef(0, 0, 0)
        
        # ==================== 左腿 ====================
        left_leg_swing = swing_angle
        self.draw_limb(
            self.limb_width, self.limb_height, self.limb_depth,
            self.pants_color,
            swing_angle=left_leg_swing,
            pivot_x=-self.body_width/4,
            pivot_y=self.limb_height,
            pivot_z=0
        )
        
        # ==================== 右腿 ====================
        right_leg_swing = -swing_angle
        self.draw_limb(
            self.limb_width, self.limb_height, self.limb_depth,
            self.pants_color,
            swing_angle=right_leg_swing,
            pivot_x=self.body_width/4,
            pivot_y=self.limb_height,
            pivot_z=0
        )
        
        # ==================== 身体 ====================
        glPushMatrix()
        glTranslatef(0, self.limb_height, 0)
        self.draw_cube(self.body_width, self.body_height, self.body_depth, self.shirt_color)
        glPopMatrix()
        
        # ==================== 左臂 ====================
        left_arm_swing = -swing_angle
        glPushMatrix()
        glTranslatef(0, self.limb_height + self.body_height - 0.02, 0)
        self.draw_limb(
            self.limb_width, self.limb_height, self.limb_depth,
            self.skin_color,
            swing_angle=left_arm_swing,
            pivot_x=-self.body_width/2 - self.limb_width/2,
            pivot_y=self.limb_height,
            pivot_z=0
        )
        glPopMatrix()
        
        # ==================== 右臂 ====================
        right_arm_swing = swing_angle
        glPushMatrix()
        glTranslatef(0, self.limb_height + self.body_height - 0.02, 0)
        self.draw_limb(
            self.limb_width, self.limb_height, self.limb_depth,
            self.skin_color,
            swing_angle=right_arm_swing,
            pivot_x=self.body_width/2 + self.limb_width/2,
            pivot_y=self.limb_height,
            pivot_z=0
        )
        glPopMatrix()
        
        # ==================== 头部 ====================
        glPushMatrix()
        glTranslatef(0, self.limb_height + self.body_height, 0)
        self.draw_cube(self.head_width, self.head_height, self.head_depth, self.skin_color)
        glPopMatrix()
        
        glPopMatrix()
