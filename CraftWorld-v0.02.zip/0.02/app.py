import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog, messagebox
import datetime
import json
import os
import pygame
from pygame.locals import *
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL.GLUT import *
import math
from player_model import AnimatedPlayerModel

class OpenGLStateManager:
    def __init__(self):
        self.current_states = {
            GL_DEPTH_TEST: True,
            GL_LIGHTING: True,
            GL_TEXTURE_2D: True,
            GL_CULL_FACE: True,
            GL_BLEND: True
        }
        self.matrix_mode = GL_MODELVIEW
        
    def set_state(self, state, enabled):
        if self.current_states.get(state, False) != enabled:
            if enabled:
                glEnable(state)
            else:
                glDisable(state)
            self.current_states[state] = enabled
    
    def set_2d_mode(self, width, height):
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, width, 0, height, -1, 1)
        
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        
        self.set_state(GL_DEPTH_TEST, False)
        self.set_state(GL_LIGHTING, False)
        self.set_state(GL_TEXTURE_2D, False)
        self.set_state(GL_CULL_FACE, False)
        
    def restore_3d_mode(self):
        glPopMatrix()
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        glMatrixMode(GL_MODELVIEW)
        
        self.set_state(GL_DEPTH_TEST, True)
        self.set_state(GL_LIGHTING, True)
        self.set_state(GL_TEXTURE_2D, True)
        self.set_state(GL_CULL_FACE, True)

class UIBatcher:
    def __init__(self):
        self.vertices = []
        self.colors = []
        self.current_color = (1.0, 1.0, 1.0, 1.0)
        
    def set_color(self, r, g, b, a=1.0):
        self.current_color = (r, g, b, a)
        
    def draw_quad(self, x, y, width, height):
        vertices = [x, y, x + width, y, x + width, y + height, x, y + height]
        self.vertices.extend(vertices)
        self.colors.extend([self.current_color] * 4)
        
    def draw_line_rect(self, x, y, width, height, line_width=1.0):
        glPushAttrib(GL_LINE_BIT)
        glLineWidth(line_width)
        glBegin(GL_LINE_LOOP)
        glVertex2f(x, y)
        glVertex2f(x + width, y)
        glVertex2f(x + width, y + height)
        glVertex2f(x, y + height)
        glEnd()
        glPopAttrib()
        
    def flush(self):
        if not self.vertices:
            return
            
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnableClientState(GL_COLOR_ARRAY)
        
        import ctypes
        vertex_array = (GLfloat * len(self.vertices))(*self.vertices)
        color_array = (GLfloat * len(self.colors) * 4)()
        idx = 0
        for color in self.colors:
            color_array[idx] = color[0]
            color_array[idx + 1] = color[1]
            color_array[idx + 2] = color[2]
            color_array[idx + 3] = color[3]
            idx += 4
        
        glVertexPointer(2, GL_FLOAT, 0, ctypes.cast(vertex_array, ctypes.POINTER(GLfloat)))
        glColorPointer(4, GL_FLOAT, 0, ctypes.cast(color_array, ctypes.POINTER(GLfloat)))
        
        glDrawArrays(GL_QUADS, 0, len(self.vertices) // 2)
        
        glDisableClientState(GL_VERTEX_ARRAY)
        glDisableClientState(GL_COLOR_ARRAY)
        
        self.vertices = []
        self.colors = []

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("CraftWorld")
        self.root.geometry("800x600")
        
        self.player_name = "Player"
        
        self.is_animating = False
        self.animation_step = 0
        self.total_steps = 30
        self.animating_btn = None
        self.target_page = None
        
        self.archives = []
        
        self.main_frame = ttk.Frame(root)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.top_frame = ttk.Frame(self.main_frame)
        self.top_frame.pack(side=tk.TOP, fill=tk.X, pady=(0, 10))
        
        self.player_info_frame = ttk.Frame(self.top_frame)
        self.player_info_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        self.avatar_frame = tk.Frame(self.player_info_frame, width=50, height=50, bg="#333333", 
                                     highlightbackground="white", highlightthickness=2)
        self.avatar_frame.pack(side=tk.LEFT, padx=(0, 10))
        self.avatar_frame.pack_propagate(False)
        self.avatar_frame.bind("<Button-1>", self.edit_player_name)
        
        self.name_label = tk.Label(self.player_info_frame, text=self.player_name, 
                                     font=("微软雅黑", 14, "bold"))
        self.name_label.pack(side=tk.LEFT)
        self.name_label.bind("<Button-1>", self.edit_player_name)
        
        self.return_btn = tk.Button(self.top_frame, text="返回", font=("微软雅黑", 12), 
                                     command=self.show_main_page, bg="#4a90d9", fg="white",
                                     relief=tk.FLAT, padx=20, pady=10)
        
        self.content_frame = ttk.Frame(self.main_frame)
        self.content_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        self.main_buttons = {}
        
        self.load_archive_list()
        
        self.show_main_page()
    
    def show_main_page(self):
        self.is_animating = False
        
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        for widget in self.top_frame.winfo_children():
            if widget != self.return_btn:
                widget.destroy()
        
        self.return_btn.pack_forget()
        
        left_frame = ttk.Frame(self.content_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        left_frame.pack_propagate(False)
        
        right_frame = ttk.Frame(self.content_frame, width=200)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=False)
        right_frame.pack_propagate(False)
        
        self.original_pady = {}
        
        button1 = tk.Button(left_frame, text="存档", font=("微软雅黑", 16),
                           command=self.show_archive_page, 
                           bg="#5cb85c", fg="white", relief=tk.FLAT)
        button1.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.main_buttons["存档"] = button1
        
        button2 = tk.Button(left_frame, text="市场", font=("微软雅黑", 16),
                           command=self.show_market_page, 
                           bg="#f0ad4e", fg="white", relief=tk.FLAT)
        button2.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        self.main_buttons["市场"] = button2
        
        button3 = tk.Button(left_frame, text="设置", font=("微软雅黑", 16),
                           command=self.show_settings_page, 
                           bg="#d9534f", fg="white", relief=tk.FLAT)
        button3.pack(fill=tk.BOTH, expand=True)
        self.main_buttons["设置"] = button3
        
        button4 = tk.Button(right_frame, text="缩放按钮", font=("微软雅黑", 16),
                           command=self.show_scale_page, 
                           bg="#5bc0de", fg="white", relief=tk.FLAT)
        button4.pack(fill=tk.BOTH, expand=True)
        self.main_buttons["缩放按钮"] = button4
    
    def load_archive_list(self):
        save_dir = "saves"
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        self.archives = []
        for filename in os.listdir(save_dir):
            if filename.endswith(".cfwd"):
                self.archives.append(filename[:-5])
    
    def show_archive_page(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        self.return_btn.pack(side=tk.LEFT)
        
        archive_frame = ttk.Frame(self.content_frame)
        archive_frame.pack(fill=tk.BOTH, expand=True)
        
        label = ttk.Label(archive_frame, text="存档列表", font=("微软雅黑", 24))
        label.pack(pady=20)
        
        listbox_frame = ttk.Frame(archive_frame)
        listbox_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        scrollbar = ttk.Scrollbar(listbox_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        listbox = tk.Listbox(listbox_frame, font=("微软雅黑", 12), yscrollcommand=scrollbar.set)
        listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        scrollbar.config(command=listbox.yview)
        
        for archive in self.archives:
            listbox.insert(tk.END, archive)
        
        button_frame = ttk.Frame(archive_frame)
        button_frame.pack(fill=tk.X, padx=20, pady=20)
        
        def join_archive():
            selection = listbox.curselection()
            if selection:
                archive_name = listbox.get(selection[0])
                self.start_game(archive_name)
        
        def new_archive():
            archive_name = simpledialog.askstring("新建存档", "请输入存档名称:")
            if archive_name:
                self.start_game(archive_name)
        
        join_btn = tk.Button(button_frame, text="加入", font=("微软雅黑", 14),
                            command=join_archive, bg="#5cb85c", fg="white", relief=tk.FLAT, padx=30)
        join_btn.pack(side=tk.LEFT, padx=10)
        
        new_btn = tk.Button(button_frame, text="新建", font=("微软雅黑", 14),
                           command=new_archive, bg="#4a90d9", fg="white", relief=tk.FLAT, padx=30)
        new_btn.pack(side=tk.LEFT, padx=10)
    
    def show_market_page(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        self.return_btn.pack(side=tk.LEFT)
        
        market_frame = ttk.Frame(self.content_frame)
        market_frame.pack(fill=tk.BOTH, expand=True)
        
        label = ttk.Label(market_frame, text="市场", font=("微软雅黑", 24))
        label.pack(pady=50)
        
        ttk.Label(market_frame, text="市场功能将在这里实现", font=("微软雅黑", 16)).pack()
    
    def show_settings_page(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        self.return_btn.pack(side=tk.LEFT)
        
        settings_frame = ttk.Frame(self.content_frame)
        settings_frame.pack(fill=tk.BOTH, expand=True)
        
        label = ttk.Label(settings_frame, text="设置页面", font=("微软雅黑", 24))
        label.pack(pady=50)
        
        ttk.Label(settings_frame, text="设置功能将在这里实现", font=("微软雅黑", 16)).pack()
    
    def show_scale_page(self):
        for widget in self.content_frame.winfo_children():
            widget.destroy()
        
        self.return_btn.pack(side=tk.LEFT)
        
        scale_frame = ttk.Frame(self.content_frame)
        scale_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        label = ttk.Label(scale_frame, text="模型管理", font=("微软雅黑", 24))
        label.pack(pady=(0, 20))
    
    def add_model(self):
        from tkinter import filedialog
        file_path = filedialog.askopenfilename(
            title="选择模型文件",
            filetypes=[("所有文件", "*")]
        )
        if file_path:
            pass
    
    def show_3d_figure(self, parent_frame, interactive=False):
        pass
    
    def edit_player_name(self, event):
        from tkinter import simpledialog
        new_name = simpledialog.askstring("修改玩家名字", "请输入新的玩家名字:", initialvalue=self.player_name)
        if new_name and new_name.strip():
            self.player_name = new_name.strip()
            self.name_label.config(text=self.player_name)

class SimpleBoxModel:
    def __init__(self, width=1.0, height=1.0, depth=1.0):
        self.width = width
        self.height = height
        self.depth = depth
    
    def draw(self):
        w = self.width / 2
        h = self.height / 2
        d = self.depth / 2
        
        glBegin(GL_QUADS)
        
        glNormal3f(0, 0, 1)
        glVertex3f(-w, -h, d)
        glVertex3f(w, -h, d)
        glVertex3f(w, h, d)
        glVertex3f(-w, h, d)
        
        glNormal3f(0, 0, -1)
        glVertex3f(w, -h, -d)
        glVertex3f(-w, -h, -d)
        glVertex3f(-w, h, -d)
        glVertex3f(w, h, -d)
        
        glNormal3f(0, 1, 0)
        glVertex3f(-w, h, d)
        glVertex3f(w, h, d)
        glVertex3f(w, h, -d)
        glVertex3f(-w, h, -d)
        
        glNormal3f(0, -1, 0)
        glVertex3f(-w, -h, -d)
        glVertex3f(w, -h, -d)
        glVertex3f(w, -h, d)
        glVertex3f(-w, -h, d)
        
        glNormal3f(1, 0, 0)
        glVertex3f(w, -h, d)
        glVertex3f(w, -h, -d)
        glVertex3f(w, h, -d)
        glVertex3f(w, h, d)
        
        glNormal3f(-1, 0, 0)
        glVertex3f(-w, -h, -d)
        glVertex3f(-w, -h, d)
        glVertex3f(-w, h, d)
        glVertex3f(-w, h, -d)
        
        glEnd()

class SimplePlayerModel:
    def __init__(self):
        pass
    
    def draw(self):
        glColor3f(0.8, 0.6, 0.4)
        
        glPushMatrix()
        glTranslatef(0, 1.2, 0)
        glScalef(0.5, 0.6, 0.3)
        SimpleBoxModel().draw()
        glPopMatrix()
        
        glColor3f(0.85, 0.65, 0.45)
        glPushMatrix()
        glTranslatef(0, 1.8, 0)
        glScalef(0.4, 0.4, 0.4)
        SimpleBoxModel().draw()
        glPopMatrix()
        
        glColor3f(0.3, 0.3, 0.5)
        glPushMatrix()
        glTranslatef(-0.15, 0.6, 0)
        glScalef(0.15, 0.6, 0.15)
        SimpleBoxModel().draw()
        glPopMatrix()
        
        glPushMatrix()
        glTranslatef(0.15, 0.6, 0)
        glScalef(0.15, 0.6, 0.15)
        SimpleBoxModel().draw()
        glPopMatrix()
        
        glColor3f(0.2, 0.2, 0.2)
        glPushMatrix()
        glTranslatef(-0.15, 0.3, 0)
        glScalef(0.15, 0.6, 0.15)
        SimpleBoxModel().draw()
        glPopMatrix()
        
        glPushMatrix()
        glTranslatef(0.15, 0.3, 0)
        glScalef(0.15, 0.6, 0.15)
        SimpleBoxModel().draw()
        glPopMatrix()

class OBJModel:
    def __init__(self, filename):
        self.vertices = []
        self.faces = []
        self.normals = []
        self.load_obj(filename)
    
    def load_obj(self, filename):
        try:
            with open(filename, 'r') as f:
                for line in f:
                    if line.startswith('v '):
                        parts = line.strip().split()
                        self.vertices.append((float(parts[1]), float(parts[2]), float(parts[3])))
                    elif line.startswith('vn '):
                        parts = line.strip().split()
                        self.normals.append((float(parts[1]), float(parts[2]), float(parts[3])))
                    elif line.startswith('f '):
                        parts = line.strip().split()
                        face = []
                        for part in parts[1:]:
                            if '//' in part:
                                v_idx, n_idx = part.split('//')
                                face.append((int(v_idx)-1, int(n_idx)-1))
                            elif '/' in part:
                                v_idx, t_idx, n_idx = (part.split('/') + ['0', '0'])[:3]
                                face.append((int(v_idx)-1, int(n_idx)-1 if n_idx else -1))
                            else:
                                face.append((int(part)-1, -1))
                        self.faces.append(face)
        except Exception as e:
            print(f"Error loading OBJ: {e}")
    
    def draw(self):
        glBegin(GL_TRIANGLES)
        for face in self.faces:
            if len(face) == 3:
                for v_idx, n_idx in face:
                    if n_idx >= 0 and n_idx < len(self.normals):
                        glNormal3fv(self.normals[n_idx])
                    glVertex3fv(self.vertices[v_idx])
            elif len(face) >= 4:
                for i in range(1, len(face)-1):
                    for idx in [0, i, i+1]:
                        v_idx, n_idx = face[idx]
                        if n_idx >= 0 and n_idx < len(self.normals):
                            glNormal3fv(self.normals[n_idx])
                        glVertex3fv(self.vertices[v_idx])
        glEnd()

class Game3D:
    def __init__(self, archive_name=None, progress_callback=None, player_name="Player"):
        self.archive_name = archive_name
        self.progress_callback = progress_callback
        self.player_name = player_name
        
        if self.progress_callback:
            self.progress_callback(2, 5, "初始化PyGame...")
        
        pygame.init()
        glutInit()
        self.display = (1024, 768)
        pygame.display.set_mode(self.display, DOUBLEBUF | OPENGL)
        pygame.display.set_caption("CraftWorld 3D")
        
        pygame.event.set_allowed([QUIT, KEYDOWN, KEYUP, MOUSEBUTTONDOWN, MOUSEBUTTONUP, MOUSEMOTION, DROPFILE])
        
        if self.progress_callback:
            self.progress_callback(3, 5, "初始化OpenGL...")
        
        self.init_opengl()
        
        self.gl_state = OpenGLStateManager()
        self.ui_batcher = UIBatcher()
        
        self.player_x = 0.0
        self.player_y = 5.0
        self.player_z = 0.0
        self.player_vx = 0.0
        self.player_vy = 0.0
        self.player_vz = 0.0
        
        self.yaw = 0.0
        self.pitch = 0.0
        
        self.move_speed = 5.0
        self.mouse_sensitivity = 0.15
        self.gravity = -25.0
        self.jump_force = 10.0
        
        self.keys = {}
        self.right_mouse_down = False
        self.last_mouse_pos = (0, 0)
        
        self.running = True
        self.paused = False
        self.pause_menu_state = "main"
        
        self.ground_y = 0
        
        self.input_mode = "keyboard"
        self.network_mode = "singleplayer"
        
        self.view_mode = "first_person"
        self.chat_open = False
        self.chat_messages = [
            "Welcome to CraftWorld!",
            "Use WASD to move, right mouse to look",
            "Drag and drop 3D models to add them!"
        ]
        self.chat_input = ""
        
        self.player_model = AnimatedPlayerModel()
        self.view_mode = "third_person"
        self.held_item_model = SimpleBoxModel(0.3, 0.3, 0.3)
        
        self.last_time = pygame.time.get_ticks()
        
        self.selected_slot = 0
        self.frame_count = 0
        self.last_fps_time = 0
        self.current_fps = 0
        
        self.name_occlusion = True  # 默认名字可以被遮挡
        
        self.network_socket = None
        self.network_connected = False
        self.network_host = "127.0.0.1"
        self.network_port = 5000
        self.room_name = "My Room"
        self.other_players = {}
        self.network_buffer = []
        self.editing_ip = False
        self.temp_ip = ""
        
        if self.progress_callback:
            self.progress_callback(4, 5, "加载存档...")
        
        if archive_name:
            self.load_world()
    
    def init_opengl(self):
        glEnable(GL_DEPTH_TEST)
        glEnable(GL_CULL_FACE)
        glEnable(GL_BLEND)
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_COLOR_MATERIAL)
        
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glCullFace(GL_BACK)
        glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE)
        
        light_ambient = [0.3, 0.3, 0.3, 1.0]
        light_diffuse = [0.8, 0.8, 0.8, 1.0]
        light_position = [10.0, 10.0, 10.0, 1.0]
        
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
        glLightfv(GL_LIGHT0, GL_POSITION, light_position)
        
        glShadeModel(GL_SMOOTH)
        
        glMatrixMode(GL_PROJECTION)
        gluPerspective(70, (self.display[0] / self.display[1]), 0.1, 1000.0)
        glMatrixMode(GL_MODELVIEW)
        
        glClearColor(0.5, 0.7, 1.0, 1.0)
    
    def draw_text(self, x, y, text, font=GLUT_BITMAP_HELVETICA_12, color=(1.0, 1.0, 1.0)):
        glPushAttrib(GL_CURRENT_BIT | GL_ENABLE_BIT)
        glDisable(GL_TEXTURE_2D)
        glDisable(GL_LIGHTING)
        glColor3f(*color)
        glRasterPos2f(x, y)
        for char in text:
            glutBitmapCharacter(font, ord(char))
        glPopAttrib()
    
    def is_on_ground(self, y):
        return y <= self.ground_y + 0.1
    
    def draw_ground(self):
        glDisable(GL_CULL_FACE)
        glDisable(GL_LIGHTING)
        
        glColor3f(0.2, 0.6, 0.2)
        glBegin(GL_QUADS)
        
        view_distance = 100
        glVertex3f(-view_distance, 0, -view_distance)
        glVertex3f(view_distance, 0, -view_distance)
        glVertex3f(view_distance, 0, view_distance)
        glVertex3f(-view_distance, 0, view_distance)
        
        glEnd()
        
        glEnable(GL_LIGHTING)
        glEnable(GL_CULL_FACE)
    
    def draw_hotbar(self):
        self.gl_state.set_2d_mode(self.display[0], self.display[1])
        
        slot_count = 9
        slot_size = 60
        slot_spacing = 8
        total_width = slot_count * slot_size + (slot_count - 1) * slot_spacing
        total_height = slot_size + 30
        
        hotbar_x = (self.display[0] - total_width) / 2
        hotbar_y = 30
        
        self.ui_batcher.set_color(0.0, 0.0, 0.0, 0.85)
        self.ui_batcher.draw_quad(hotbar_x, hotbar_y, total_width, total_height)
        
        for i in range(slot_count):
            slot_x = hotbar_x + i * (slot_size + slot_spacing)
            slot_y = hotbar_y + 15
            
            if i == self.selected_slot:
                self.ui_batcher.set_color(1.0, 0.7, 0.0, 0.95)
            else:
                self.ui_batcher.set_color(0.15, 0.15, 0.15, 0.9)
            self.ui_batcher.draw_quad(slot_x + 4, slot_y + 4, slot_size - 8, slot_size - 8)
        
        self.ui_batcher.flush()
        
        glColor3f(1.0, 1.0, 1.0)
        glLineWidth(4.0)
        self.ui_batcher.draw_line_rect(hotbar_x - 4, hotbar_y - 4, total_width + 8, total_height + 8)
        
        glColor3f(0.0, 0.0, 0.0)
        glLineWidth(2.0)
        self.ui_batcher.draw_line_rect(hotbar_x - 2, hotbar_y - 2, total_width + 4, total_height + 4)
        
        for i in range(slot_count):
            slot_x = hotbar_x + i * (slot_size + slot_spacing)
            slot_y = hotbar_y + 15
            
            glColor3f(1.0, 1.0, 1.0)
            glLineWidth(3.0)
            self.ui_batcher.draw_line_rect(slot_x, slot_y, slot_size, slot_size)
            
            glColor3f(0.0, 0.0, 0.0)
            glLineWidth(2.0)
            self.ui_batcher.draw_line_rect(slot_x + 2, slot_y + 2, slot_size - 4, slot_size - 4)
            
            if i == self.selected_slot:
                glColor3f(1.0, 1.0, 0.0)
                glLineWidth(3.0)
                self.ui_batcher.draw_line_rect(slot_x - 2, slot_y - 2, slot_size + 4, slot_size + 4)
                
                num_text = str(i + 1)
                self.draw_text(slot_x + slot_size/2 - 6, slot_y + slot_size + 5, num_text, GLUT_BITMAP_HELVETICA_18, (1.0, 1.0, 0.0))
            else:
                num_text = str(i + 1)
                self.draw_text(slot_x + slot_size/2 - 6, slot_y + slot_size + 5, num_text, GLUT_BITMAP_HELVETICA_18, (1.0, 1.0, 1.0))
        
        glLineWidth(1.0)
        
        self.gl_state.restore_3d_mode()
    
    def draw_player_name(self):
        if self.view_mode != "third_person":
            return
        
        self.gl_state.set_2d_mode(self.display[0], self.display[1])
        
        if not self.name_occlusion:
            glDisable(GL_DEPTH_TEST)
        
        name_y = self.display[1] / 2 + 150
        name_x = self.display[0] / 2
        
        text_width = len(self.player_name) * 9
        self.draw_text(name_x - text_width/2, name_y, self.player_name, GLUT_BITMAP_HELVETICA_18)
        
        if not self.name_occlusion:
            glEnable(GL_DEPTH_TEST)
        
        self.gl_state.restore_3d_mode()
    
    def render(self):
        current_time = pygame.time.get_ticks()
        self.frame_count += 1
        if current_time - self.last_fps_time >= 1000:
            self.current_fps = self.frame_count
            self.frame_count = 0
            self.last_fps_time = current_time
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
        
        self.setup_3d_camera()
        
        self.render_3d_scene()
        
        self.render_2d_ui()
        
        pygame.display.flip()
    
    def setup_3d_camera(self):
        yaw_rad = math.radians(self.yaw)
        pitch_rad = math.radians(self.pitch)
        
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(70, (self.display[0] / self.display[1]), 0.1, 1000.0)
        
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        
        if self.view_mode == "first_person" or not self.player_model:
            look_x = self.player_x + math.sin(yaw_rad) * math.cos(pitch_rad)
            look_y = self.player_y + 1.6 + math.sin(pitch_rad)
            look_z = self.player_z + math.cos(yaw_rad) * math.cos(pitch_rad)
            
            gluLookAt(
                self.player_x, self.player_y + 1.6, self.player_z,
                look_x, look_y, look_z,
                0, 1, 0
            )
        else:
            camera_distance = 5.0
            camera_x = self.player_x - math.sin(yaw_rad) * math.cos(pitch_rad) * camera_distance
            camera_y = self.player_y + 1.6 - math.sin(pitch_rad) * camera_distance + 2.0
            camera_z = self.player_z - math.cos(yaw_rad) * math.cos(pitch_rad) * camera_distance
            
            look_x = self.player_x
            look_y = self.player_y + 1.0
            look_z = self.player_z
            
            gluLookAt(
                camera_x, camera_y, camera_z,
                look_x, look_y, look_z,
                0, 1, 0
            )
    
    def render_3d_scene(self):
        self.draw_ground()
        
        self.receive_network_data()
        self.send_network_data()
        self.draw_other_players()
        
        if self.view_mode == "third_person" and self.player_model:
            glPushMatrix()
            glTranslatef(self.player_x, self.player_y, self.player_z)
            glRotatef(-self.yaw + 180, 0, 1, 0)
            self.player_model.draw()
            glPopMatrix()
        
        if self.held_item_model:
            glPushMatrix()
            yaw_rad = math.radians(self.yaw)
            pitch_rad = math.radians(self.pitch)
            item_x = self.player_x + math.sin(yaw_rad) * 0.5
            item_y = self.player_y + 1.2
            item_z = self.player_z + math.cos(yaw_rad) * 0.5
            glTranslatef(item_x, item_y, item_z)
            glRotatef(-self.yaw, 0, 1, 0)
            glRotatef(-self.pitch, 1, 0, 0)
            if isinstance(self.held_item_model, SimpleBoxModel):
                glColor3f(0.8, 0.2, 0.2)
            else:
                glScalef(0.3, 0.3, 0.3)
                glColor3f(0.9, 0.9, 0.9)
            self.held_item_model.draw()
            glPopMatrix()
    
    def render_2d_ui(self):
        self.draw_hotbar()
        self.draw_player_name()
        self.draw_hud()
        self.draw_fps()
        
        if self.chat_open:
            self.draw_chat()
        
        if self.paused:
            self.draw_pause_menu()
    
    def draw_fps(self):
        self.gl_state.set_2d_mode(self.display[0], self.display[1])
        
        fps_text = f"FPS: {self.current_fps}"
        self.draw_text(10, self.display[1] - 30, fps_text, GLUT_BITMAP_HELVETICA_18, (1.0, 1.0, 0.0))
        
        if self.player_model:
            self.draw_text(10, self.display[1] - 60, "Player model loaded", GLUT_BITMAP_HELVETICA_12, (0.0, 1.0, 0.0))
        if self.held_item_model:
            self.draw_text(10, self.display[1] - 80, "Held item loaded", GLUT_BITMAP_HELVETICA_12, (0.0, 1.0, 0.0))
        
        self.gl_state.restore_3d_mode()
    
    def draw_hud(self):
        self.gl_state.set_2d_mode(self.display[0], self.display[1])
        
        button_width = 100
        button_height = 50
        button_spacing = 15
        start_x = self.display[0] - button_width - 30
        start_y = self.display[1] - 30 - button_height
        
        buttons = [
            ("View", 0),
            ("Chat", 1),
            ("Pause", 2)
        ]
        
        self.ui_batcher.set_color(0.3, 0.5, 0.8)
        for i, (text, index) in enumerate(buttons):
            x = start_x
            y = start_y - i * (button_height + button_spacing)
            self.ui_batcher.draw_quad(x, y, button_width, button_height)
        
        self.ui_batcher.flush()
        
        for i, (text, index) in enumerate(buttons):
            x = start_x
            y = start_y - i * (button_height + button_spacing)
            self.draw_text(x + (button_width/2) - (len(text)*7), y + button_height/2, text, GLUT_BITMAP_HELVETICA_18)
        
        self.gl_state.restore_3d_mode()
    
    def handle_hud_click(self, pos):
        mouse_x, mouse_y = pos
        mouse_y = self.display[1] - mouse_y
        
        button_width = 100
        button_height = 50
        button_spacing = 15
        start_x = self.display[0] - button_width - 30
        start_y = self.display[1] - 30 - button_height
        
        buttons = [
            ("View", 0),
            ("Chat", 1),
            ("Pause", 2)
        ]
        
        for i, (text, index) in enumerate(buttons):
            x = start_x
            y = start_y - i * (button_height + button_spacing)
            
            if (x <= mouse_x <= x + button_width and
                y <= mouse_y <= y + button_height):
                if index == 0:
                    if self.view_mode == "first_person":
                        self.view_mode = "third_person"
                    else:
                        self.view_mode = "first_person"
                elif index == 1:
                    self.chat_open = not self.chat_open
                elif index == 2:
                    self.paused = True
                    self.pause_menu_state = "main"
                return True
        return False
    
    def draw_chat(self):
        self.gl_state.set_2d_mode(self.display[0], self.display[1])
        
        chat_width = 400
        chat_height = 200
        chat_x = 20
        chat_y = 100
        
        self.ui_batcher.set_color(0.0, 0.0, 0.0, 0.7)
        self.ui_batcher.draw_quad(chat_x, chat_y, chat_width, chat_height)
        
        input_height = 30
        self.ui_batcher.set_color(0.2, 0.2, 0.2, 0.8)
        self.ui_batcher.draw_quad(chat_x, chat_y - 10, chat_width, input_height)
        
        self.ui_batcher.flush()
        
        glColor3f(1.0, 1.0, 1.0)
        message_y = chat_y + chat_height - 20
        for message in reversed(self.chat_messages[-10:]):
            self.draw_text(chat_x + 10, message_y, message, GLUT_BITMAP_HELVETICA_12)
            message_y -= 20
            if message_y < chat_y + 10:
                break
        
        input_text = "Say: " + self.chat_input
        self.draw_text(chat_x + 10, chat_y - 10 - input_height/2, input_text, GLUT_BITMAP_HELVETICA_12)
        
        self.gl_state.restore_3d_mode()
    
    def draw_pause_menu(self):
        self.gl_state.set_2d_mode(self.display[0], self.display[1])
        
        if self.pause_menu_state == "main":
            self.draw_pause_main_menu()
        elif self.pause_menu_state == "settings":
            self.draw_settings_menu()
        elif self.pause_menu_state == "network":
            self.draw_network_menu()
        
        self.gl_state.restore_3d_mode()
    
    def draw_pause_main_menu(self):
        self.ui_batcher.set_color(0.0, 0.0, 0.0, 0.7)
        self.ui_batcher.draw_quad(0, 0, self.display[0], self.display[1])
        
        buttons = [
            ("Resume", -40, 60, 0),
            ("Save", -20, 10, 1),
            ("Settings", -20, -40, 2),
            ("Network", -40, -90, 3),
            ("Exit", -20, -140, 4)
        ]
        
        self.ui_batcher.set_color(0.3, 0.5, 0.8)
        for text, x_offset, y_offset, index in buttons:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            if 0 <= index < len(buttons):
                self.ui_batcher.draw_quad(button_x - 70, button_y - 15, 140, 40)
        
        self.ui_batcher.flush()
        
        self.draw_text(self.display[0]/2 - 50, self.display[1]/2 + 120, "Game Paused", GLUT_BITMAP_HELVETICA_18)
        
        for text, x_offset, y_offset, index in buttons:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            if 0 <= index < len(buttons):
                self.draw_text(button_x - (len(text)*6), button_y + 5, text, GLUT_BITMAP_HELVETICA_12)
    
    def draw_settings_menu(self):
        self.ui_batcher.set_color(0.0, 0.0, 0.0, 0.8)
        self.ui_batcher.draw_quad(0, 0, self.display[0], self.display[1])
        
        options = [
            ("Keyboard", -60, 40, "keyboard"),
            ("Touch", -45, -10, "touch")
        ]
        
        for text, x_offset, y_offset, mode in options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            if mode == self.input_mode:
                self.ui_batcher.set_color(0.2, 0.7, 0.3)
            else:
                self.ui_batcher.set_color(0.4, 0.4, 0.4)
            self.ui_batcher.draw_quad(button_x - 70, button_y - 15, 140, 40)
        
        name_options = [
            ("Occluded", -70, -110, "occluded"),
            ("See Through", -60, -160, "see_through")
        ]
        
        for text, x_offset, y_offset, mode in name_options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            if (mode == "occluded" and self.name_occlusion) or \
               (mode == "see_through" and not self.name_occlusion):
                self.ui_batcher.set_color(0.2, 0.7, 0.3)
            else:
                self.ui_batcher.set_color(0.4, 0.4, 0.4)
            self.ui_batcher.draw_quad(button_x - 70, button_y - 15, 140, 40)
        
        back_y = self.display[1]/2 - 230
        back_x = self.display[0]/2 - 25
        self.ui_batcher.set_color(0.5, 0.5, 0.5)
        self.ui_batcher.draw_quad(back_x - 60, back_y - 15, 120, 40)
        
        self.ui_batcher.flush()
        
        self.draw_text(self.display[0]/2 - 40, self.display[1]/2 + 140, "Settings", GLUT_BITMAP_HELVETICA_18)
        self.draw_text(self.display[0]/2 - 80, self.display[1]/2 + 80, "Controls:", GLUT_BITMAP_HELVETICA_12)
        
        for text, x_offset, y_offset, mode in options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            self.draw_text(button_x - (len(text)*6), button_y + 5, text, GLUT_BITMAP_HELVETICA_12)
        
        self.draw_text(self.display[0]/2 - 90, self.display[1]/2 - 60, "Name Display:", GLUT_BITMAP_HELVETICA_12)
        
        for text, x_offset, y_offset, mode in name_options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            self.draw_text(button_x - (len(text)*6), button_y + 5, text, GLUT_BITMAP_HELVETICA_12)
        
        self.draw_text(back_x - 24, back_y + 5, "Back", GLUT_BITMAP_HELVETICA_12)
    
    def draw_network_menu(self):
        self.ui_batcher.set_color(0.0, 0.0, 0.0, 0.8)
        self.ui_batcher.draw_quad(0, 0, self.display[0], self.display[1])
        
        options = [
            ("Create Room", -40, 80, "create"),
            ("Join Room", -40, 20, "join"),
            ("Single Player", -40, -40, "single")
        ]
        
        for text, x_offset, y_offset, mode in options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            if (mode == "create" and self.network_mode == "host") or \
               (mode == "join" and self.network_mode == "client") or \
               (mode == "single" and self.network_mode == "singleplayer"):
                self.ui_batcher.set_color(0.2, 0.7, 0.3)
            else:
                self.ui_batcher.set_color(0.4, 0.4, 0.4)
            self.ui_batcher.draw_quad(button_x - 70, button_y - 15, 140, 40)
        
        ip_box_x = self.display[0]/2 + 20
        ip_box_y = self.display[1]/2 - 105
        ip_box_width = 150
        ip_box_height = 30
        
        self.ui_batcher.set_color(0.3, 0.3, 0.3)
        self.ui_batcher.draw_quad(ip_box_x, ip_box_y, ip_box_width, ip_box_height)
        
        if self.editing_ip:
            display_ip = self.temp_ip
            cursor_x = ip_box_x + 5 + len(display_ip) * 9
            self.ui_batcher.set_color(1.0, 1.0, 1.0)
            self.ui_batcher.draw_quad(cursor_x, ip_box_y + 5, 2, 20)
        
        back_y = self.display[1]/2 - 200
        back_x = self.display[0]/2 - 25
        self.ui_batcher.set_color(0.5, 0.5, 0.5)
        self.ui_batcher.draw_quad(back_x - 60, back_y - 15, 120, 40)
        
        self.ui_batcher.flush()
        
        self.draw_text(self.display[0]/2 - 60, self.display[1]/2 + 160, "Network", GLUT_BITMAP_HELVETICA_18)
        
        for text, x_offset, y_offset, mode in options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            self.draw_text(button_x - (len(text)*6), button_y + 5, text, GLUT_BITMAP_HELVETICA_12)
        
        ip_label_x = self.display[0]/2 - 100
        ip_label_y = self.display[1]/2 - 100
        self.draw_text(ip_label_x, ip_label_y, "Server IP:", GLUT_BITMAP_HELVETICA_12)
        
        self.ui_batcher.draw_line_rect(ip_box_x, ip_box_y, ip_box_width, ip_box_height)
        
        display_ip = self.temp_ip if self.editing_ip else self.network_host
        self.draw_text(ip_box_x + 5, ip_box_y + 8, display_ip, GLUT_BITMAP_HELVETICA_12)
        
        if self.network_connected:
            status_text = "Connected"
            status_color = (0.2, 0.8, 0.2)
        else:
            status_text = "Not Connected"
            status_color = (0.8, 0.2, 0.2)
        
        self.draw_text(self.display[0]/2 - 50, self.display[1]/2 - 150, status_text, GLUT_BITMAP_HELVETICA_12, status_color)
        
        self.draw_text(back_x - 24, back_y + 5, "Back", GLUT_BITMAP_HELVETICA_12)
    
    def handle_pause_click(self, pos):
        mouse_x, mouse_y = pos
        mouse_y = self.display[1] - mouse_y
        
        if self.pause_menu_state == "main":
            self.handle_main_menu_click(mouse_x, mouse_y)
        elif self.pause_menu_state == "settings":
            self.handle_settings_menu_click(mouse_x, mouse_y)
        elif self.pause_menu_state == "network":
            self.handle_network_menu_click(mouse_x, mouse_y)
    
    def handle_main_menu_click(self, x, y):
        buttons = [
            ("Resume", -40, 60, 0),
            ("Save", -20, 10, 1),
            ("Settings", -20, -40, 2),
            ("Network", -40, -90, 3),
            ("Exit", -20, -140, 4)
        ]
        
        for text, x_offset, y_offset, index in buttons:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            
            if (button_x - 70 <= x <= button_x + 70 and
                button_y - 15 <= y <= button_y + 25):
                if index == 0:
                    self.paused = False
                    self.pause_menu_state = "main"
                elif index == 1:
                    self.save_world()
                elif index == 2:
                    self.pause_menu_state = "settings"
                elif index == 3:
                    self.pause_menu_state = "network"
                elif index == 4:
                    self.save_world()
                    self.running = False
                return
    
    def handle_settings_menu_click(self, x, y):
        options = [
            ("Keyboard", -60, 40, "keyboard"),
            ("Touch", -45, -10, "touch")
        ]
        
        for text, x_offset, y_offset, mode in options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            
            if (button_x - 70 <= x <= button_x + 70 and
                button_y - 15 <= y <= button_y + 25):
                self.input_mode = mode
                return
        
        name_options = [
            ("Occluded", -70, -110, "occluded"),
            ("See Through", -60, -160, "see_through")
        ]
        
        for text, x_offset, y_offset, mode in name_options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            
            if (button_x - 70 <= x <= button_x + 70 and
                button_y - 15 <= y <= button_y + 25):
                if mode == "occluded":
                    self.name_occlusion = True
                elif mode == "see_through":
                    self.name_occlusion = False
                return
        
        back_y = self.display[1]/2 - 230
        back_x = self.display[0]/2 - 25
        if (back_x - 60 <= x <= back_x + 60 and
            back_y - 15 <= y <= back_y + 25):
            self.pause_menu_state = "main"
    
    def handle_network_menu_click(self, x, y):
        options = [
            ("Create Room", -40, 80, "create"),
            ("Join Room", -40, 20, "join"),
            ("Single Player", -40, -40, "single")
        ]
        
        for text, x_offset, y_offset, mode in options:
            button_y = self.display[1]/2 + y_offset
            button_x = self.display[0]/2 + x_offset
            
            if (button_x - 70 <= x <= button_x + 70 and
                button_y - 15 <= y <= button_y + 25):
                if mode == "create":
                    self.create_network_room()
                elif mode == "join":
                    self.join_network_room(self.network_host)
                elif mode == "single":
                    self.disconnect_network()
                return
        
        # IP地址输入框点击检测
        ip_box_x = self.display[0]/2 + 20
        ip_box_y = self.display[1]/2 - 105
        ip_box_width = 150
        ip_box_height = 30
        
        if (ip_box_x <= x <= ip_box_x + ip_box_width and
            ip_box_y <= y <= ip_box_y + ip_box_height):
            self.editing_ip = True
            self.temp_ip = self.network_host
        
        back_y = self.display[1]/2 - 200
        back_x = self.display[0]/2 - 25
        if (back_x - 60 <= x <= back_x + 60 and
            back_y - 15 <= y <= back_y + 25):
            self.pause_menu_state = "main"
    
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                self.running = False
            elif event.type == KEYDOWN:
                self.keys[event.key] = True
                
                if self.editing_ip:
                    if event.key == K_RETURN:
                        self.network_host = self.temp_ip
                        self.editing_ip = False
                    elif event.key == K_BACKSPACE:
                        self.temp_ip = self.temp_ip[:-1]
                    elif event.key == K_ESCAPE:
                        self.editing_ip = False
                    else:
                        if event.unicode and len(event.unicode) == 1:
                            self.temp_ip += event.unicode
                elif self.chat_open:
                    if event.key == K_RETURN:
                        if self.chat_input:
                            self.chat_messages.append(f"{self.player_name}: {self.chat_input}")
                            self.chat_input = ""
                    elif event.key == K_BACKSPACE:
                        self.chat_input = self.chat_input[:-1]
                    elif event.key == K_ESCAPE:
                        self.chat_open = False
                    else:
                        if event.unicode and len(event.unicode) == 1:
                            self.chat_input += event.unicode
                else:
                    if event.key == K_1:
                        self.selected_slot = 0
                    elif event.key == K_2:
                        self.selected_slot = 1
                    elif event.key == K_3:
                        self.selected_slot = 2
                    elif event.key == K_4:
                        self.selected_slot = 3
                    elif event.key == K_5:
                        self.selected_slot = 4
                    elif event.key == K_6:
                        self.selected_slot = 5
                    elif event.key == K_7:
                        self.selected_slot = 6
                    elif event.key == K_8:
                        self.selected_slot = 7
                    elif event.key == K_9:
                        self.selected_slot = 8
                    elif event.key == K_ESCAPE:
                        if self.paused and self.pause_menu_state != "main":
                            self.pause_menu_state = "main"
                        else:
                            self.paused = not self.paused
                            if not self.paused:
                                self.pause_menu_state = "main"
                    elif event.key == K_q and self.paused:
                        self.running = False
            elif event.type == KEYUP:
                self.keys[event.key] = False
            elif event.type == DROPFILE:
                self.handle_drop_file(event.file)
            elif event.type == MOUSEBUTTONDOWN:
                if self.chat_open:
                    self.chat_open = False
                else:
                    if event.button == 3:
                        self.right_mouse_down = True
                        self.last_mouse_pos = pygame.mouse.get_pos()
                    elif event.button == 1:
                        if self.paused:
                            self.handle_pause_click(event.pos)
                        else:
                            if not self.handle_hud_click(event.pos):
                                pass
            elif event.type == MOUSEBUTTONUP:
                if event.button == 3:
                    self.right_mouse_down = False
            elif event.type == MOUSEMOTION:
                if self.right_mouse_down and not self.paused and not self.chat_open:
                    dx, dy = event.rel
                    self.yaw -= dx * self.mouse_sensitivity
                    self.pitch += dy * self.mouse_sensitivity
                    self.pitch = max(-89, min(89, self.pitch))
    
    def create_network_room(self):
        import socket
        try:
            self.network_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.network_socket.bind(('0.0.0.0', self.network_port))
            self.network_socket.settimeout(0.1)
            self.network_connected = True
            self.network_mode = "host"
            self.chat_messages.append(f"Room created on port {self.network_port}")
        except Exception as e:
            self.chat_messages.append(f"Failed to create room: {e}")
    
    def join_network_room(self, host_ip):
        import socket
        try:
            self.network_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.network_socket.settimeout(0.1)
            self.network_host = host_ip
            self.network_connected = True
            self.network_mode = "client"
            self.send_network_data()
            self.chat_messages.append(f"Joined room at {host_ip}:{self.network_port}")
        except Exception as e:
            self.chat_messages.append(f"Failed to join room: {e}")
    
    def send_network_data(self):
        if not self.network_connected or not self.network_socket:
            return
        try:
            import json
            data = json.dumps({
                'name': self.player_name,
                'x': self.player_x,
                'y': self.player_y,
                'z': self.player_z,
                'yaw': self.yaw,
                'pitch': self.pitch
            })
            if self.network_mode == "host":
                for addr in list(self.other_players.keys()):
                    try:
                        self.network_socket.sendto(data.encode(), addr)
                    except:
                        pass
            else:
                self.network_socket.sendto(data.encode(), (self.network_host, self.network_port))
        except:
            pass
    
    def receive_network_data(self):
        if not self.network_connected or not self.network_socket:
            return
        try:
            import json
            while True:
                try:
                    data, addr = self.network_socket.recvfrom(1024)
                    player_data = json.loads(data.decode())
                    self.other_players[addr] = player_data
                    if self.network_mode == "host":
                        self.relay_network_data(data, addr)
                except:
                    break
        except:
            pass
    
    def relay_network_data(self, data, exclude_addr):
        if not self.network_socket or self.network_mode != "host":
            return
        for addr in list(self.other_players.keys()):
            if addr != exclude_addr:
                try:
                    self.network_socket.sendto(data, addr)
                except:
                    pass
    
    def disconnect_network(self):
        if self.network_socket:
            try:
                self.network_socket.close()
            except:
                pass
        self.network_socket = None
        self.network_connected = False
        self.other_players.clear()
        self.network_mode = "singleplayer"
    
    def draw_other_players(self):
        for addr, player in self.other_players.items():
            try:
                x = player['x']
                y = player['y']
                z = player['z']
                yaw = player['yaw']
                
                glPushMatrix()
                glTranslatef(x, y, z)
                glRotatef(-yaw + 180, 0, 1, 0)
                if self.player_model:
                    glColor3f(0.6, 0.4, 0.8)
                    self.player_model.draw()
                glPopMatrix()
                
                self.draw_other_player_name(x, y + 2.5, z, player.get('name', 'Player'))
            except:
                pass
    
    def draw_other_player_name(self, x, y, z, name):
        glMatrixMode(GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, self.display[0], 0, self.display[1], -1, 1)
        
        glMatrixMode(GL_MODELVIEW)
        glPushMatrix()
        glLoadIdentity()
        
        if not self.name_occlusion:
            glDisable(GL_DEPTH_TEST)
        glDisable(GL_LIGHTING)
        glDisable(GL_TEXTURE_2D)
        
        name_y = self.display[1] / 2 + 150  # 把名字显示调高
        name_x = self.display[0] / 2
        
        glColor3f(0.8, 0.6, 1.0)
        text_width = len(name) * 9
        self.draw_text(name_x - text_width/2, name_y, name, GLUT_BITMAP_HELVETICA_12)
        
        glEnable(GL_TEXTURE_2D)
        glEnable(GL_LIGHTING)
        if not self.name_occlusion:
            glEnable(GL_DEPTH_TEST)
        
        glPopMatrix()
        
        glMatrixMode(GL_PROJECTION)
        glPopMatrix()
        
        glMatrixMode(GL_MODELVIEW)
    
    def handle_drop_file(self, filepath):
        filename = os.path.basename(filepath)
        
        if filename.lower().endswith(('_c.obj', '_c.3ds', '_c.glb', '_c.gltf', '_c.fbx')):
            base_name = filename[:-6]
            obj_path = os.path.join(os.path.dirname(filepath), base_name + '.obj')
            
            if os.path.exists(obj_path):
                try:
                    self.player_model = OBJModel(obj_path)
                    self.view_mode = "third_person"
                    self.chat_messages.append(f"Loaded player model: {base_name}")
                except Exception as e:
                    self.chat_messages.append(f"Error loading player model: {e}")
            elif filename.lower().endswith('.obj'):
                try:
                    self.player_model = OBJModel(filepath)
                    self.view_mode = "third_person"
                    self.chat_messages.append(f"Loaded player model: {filename}")
                except Exception as e:
                    self.chat_messages.append(f"Error loading player model: {e}")
        
        elif filename.lower().endswith(('_t.obj', '_t.3ds', '_t.glb', '_t.gltf', '_t.fbx')):
            base_name = filename[:-6]
            obj_path = os.path.join(os.path.dirname(filepath), base_name + '.obj')
            
            if os.path.exists(obj_path):
                try:
                    self.held_item_model = OBJModel(obj_path)
                    self.chat_messages.append(f"Loaded held item: {base_name}")
                except Exception as e:
                    self.chat_messages.append(f"Error loading held item: {e}")
            elif filename.lower().endswith('.obj'):
                try:
                    self.held_item_model = OBJModel(filepath)
                    self.chat_messages.append(f"Loaded held item: {filename}")
                except Exception as e:
                    self.chat_messages.append(f"Error loading held item: {e}")
        
        elif filename.lower().endswith('.obj'):
            try:
                self.held_item_model = OBJModel(filepath)
                self.chat_messages.append(f"Loaded model as held item: {filename}")
            except Exception as e:
                self.chat_messages.append(f"Error loading model: {e}")
        
        else:
            self.chat_messages.append(f"Unsupported file: {filename}")
    
    def update(self, dt):
        if self.paused or self.chat_open:
            return
        
        old_x, old_z = self.player_x, self.player_z
        
        yaw_rad = math.radians(self.yaw)
        move_speed = 10 * dt
        
        forward_x = math.sin(yaw_rad)
        forward_z = math.cos(yaw_rad)
        right_x = math.cos(yaw_rad)
        right_z = -math.sin(yaw_rad)
        
        dx = 0
        dz = 0
        
        if (self.keys.get(ord('w'), False) or 
            self.keys.get(ord('W'), False) or
            self.keys.get(K_w, False) or
            self.keys.get(K_UP, False)):
            dx += forward_x
            dz += forward_z
        if (self.keys.get(ord('s'), False) or 
            self.keys.get(ord('S'), False) or
            self.keys.get(K_s, False) or
            self.keys.get(K_DOWN, False)):
            dx -= forward_x
            dz -= forward_z
        if (self.keys.get(ord('a'), False) or 
            self.keys.get(ord('A'), False) or
            self.keys.get(K_a, False) or
            self.keys.get(K_LEFT, False)):
            dx -= right_x
            dz -= right_z
        if (self.keys.get(ord('d'), False) or 
            self.keys.get(ord('D'), False) or
            self.keys.get(K_d, False) or
            self.keys.get(K_RIGHT, False)):
            dx += right_x
            dz += right_z
        
        is_moving = False
        length = math.sqrt(dx*dx + dz*dz)
        if length > 0:
            dx /= length
            dz /= length
            self.player_x += dx * move_speed
            self.player_z += dz * move_speed
            is_moving = True
        
        self.player_vy += self.gravity * dt
        
        if (self.keys.get(K_SPACE, False) or 
            self.keys.get(ord(' '), False)) and self.is_on_ground(self.player_y):
            self.player_vy = self.jump_force
        
        new_y = self.player_y + self.player_vy * dt
        
        if self.is_on_ground(new_y):
            self.player_vy = 0
            self.player_y = self.ground_y
        else:
            self.player_y = new_y
        
        # 更新玩家模型动画
        if hasattr(self.player_model, 'update'):
            self.player_model.update(dt, is_moving)
    
    def load_world(self):
        try:
            save_dir = "saves"
            filename = os.path.join(save_dir, f"{self.archive_name}.cfwd")
            
            if os.path.exists(filename):
                with open(filename, 'r', encoding='utf-8') as f:
                    archive_data = json.load(f)
                
                self.player_x = archive_data.get("player_x", 0.0)
                self.player_y = archive_data.get("player_y", 5.0)
                self.player_z = archive_data.get("player_z", 0.0)
            else:
                print(f"创建新存档: {self.archive_name}")
        except Exception as e:
            print(f"加载世界失败: {e}")
    
    def save_world(self):
        try:
            save_dir = "saves"
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
            
            archive_data = {
                "name": self.archive_name,
                "player_x": self.player_x,
                "player_y": self.player_y,
                "player_z": self.player_z
            }
            
            filename = os.path.join(save_dir, f"{self.archive_name}.cfwd")
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(archive_data, f)
        except Exception as e:
            print(f"保存失败: {e}")
    
    def run(self):
        clock = pygame.time.Clock()
        
        try:
            while self.running:
                dt = clock.tick(60) / 1000.0
                
                dt = min(dt, 0.1)
                
                self.handle_events()
                self.update(dt)
                self.render()
        except Exception as e:
            print(f"游戏运行错误: {e}")
        finally:
            if self.archive_name:
                try:
                    self.save_world()
                except Exception as e:
                    print(f"保存失败: {e}")
            try:
                pygame.quit()
            except Exception as e:
                print(f"PyGame退出失败: {e}")

def start_game(archive_name, player_name="Player"):
    root = tk._default_root
    if root:
        root.withdraw()
    
    game = Game3D(archive_name, player_name=player_name)
    game.run()
    
    if root:
        root.deiconify()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    
    def start_game_wrapper(archive_name):
        start_game(archive_name, app.player_name)
    
    app.start_game = start_game_wrapper
    
    root.mainloop()
