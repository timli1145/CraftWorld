from cx_Freeze import setup, Executable

setup(
    name="CraftWorld",
    version="0.1",
    description="CraftWorld",
    executables=[Executable("app.py", base="gui")]
)